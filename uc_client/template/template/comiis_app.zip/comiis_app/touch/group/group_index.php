<?PHP exit('Access Denied');?>
<script>window.location.href = 'forum.php?mod=forumdisplay&action=list&fid={$_GET['fid']}'</script>