<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{template group/comiis_grouplist}-->
<!--{template common/footer}-->