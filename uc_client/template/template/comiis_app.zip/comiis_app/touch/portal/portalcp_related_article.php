<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{eval comiis_load('UHZPJXqN0SneQ016wP', 'op,ra,articlelist,category,searchkey,count,catid,aid');}-->
<!--{template common/footer}-->