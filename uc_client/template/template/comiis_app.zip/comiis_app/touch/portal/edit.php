<?PHP exit('Access Denied');?>
<!--{eval comiis_load('m9j3D7CGGpjP2Mg62i', 'form_url,topicurl,topicid,viewurl,aid,secqaacheck,seccodecheck,article');}-->