<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{eval $comiis_upload_url = 'misc.php?mod=swfupload&action=swfupload&operation=portal&inajax=1&infloat=yes';}-->
<!--{eval comiis_load('maaaFgGeKee7GE6h6e', 'comiis_upload_url,op,aid,article_add_url,article,article_content,stylecheck,category,categoryselect,from_cookie,idtypes,category,article_tags,tag_names,attachs,secqaacheck,seccodecheck');}-->
<!--{eval $comiis_foot = 'no';}-->
<!--{template common/footer}-->