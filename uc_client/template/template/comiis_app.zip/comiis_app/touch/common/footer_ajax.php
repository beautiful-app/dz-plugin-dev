<?PHP exit('Access Denied');?>
<!--{echo comiis_output_ajaxs()}-->]]></root><!--{eval exit;}-->