<?PHP exit('Access Denied');?>
<!--{eval comiis_load('JnZNyjJh92zfGlzHhN', 'comiis_upload_url,aid,catid,swfconfig');}-->