<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{eval comiis_load('Rz0379Un8288YEUEM0', '');}-->
<!--{template common/footer}-->