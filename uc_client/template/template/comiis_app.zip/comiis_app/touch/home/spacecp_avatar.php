<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<script type="text/javascript">
	window.location.href = 'home.php?mod=space&do=profile&mycenter=1';
</script>
<!--{template common/footer}-->