<?PHP exit('Access Denied');?>
<!--{eval comiis_load('XTRFr30sFXtt47FRtb', 'theurl,topicid');}-->