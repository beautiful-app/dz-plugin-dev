<?PHP exit('Access Denied');?>
<!--{eval comiis_load('KtN5t10G2UEtEn2JEn', 'clicks,click_multi,maxclicknum,idtype,id,hash,clickuserlist');}-->