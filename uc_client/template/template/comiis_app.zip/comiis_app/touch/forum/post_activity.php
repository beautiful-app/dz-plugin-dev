<?PHP exit('Access Denied');?>
<!--{eval comiis_load('IZa5CBAbZ9vQ89R8pp', 'activity,activitytypelist');}-->
<!--{eval comiis_load('fp4ZH45bRpBrQM5VPp', 'allowpostimg,activityattach,swfconfig');}-->