<?PHP exit('Access Denied');?>
<!--{eval comiis_load('VdaVCuA9FCW44385DD', 'debate');}-->
<!--{hook/post_debate_extra}-->