<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{eval require_once("./template/comiis_app/comiis/php/comiis_relatekw.php");}-->
{echo comiis_relatekw();}
<!--{template common/footer}-->