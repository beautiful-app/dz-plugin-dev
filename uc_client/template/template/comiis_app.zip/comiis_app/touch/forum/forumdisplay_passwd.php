<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{eval comiis_load('sJ4nsJFRMVonBRVMrQ', '');}-->
<!--{template common/footer}-->