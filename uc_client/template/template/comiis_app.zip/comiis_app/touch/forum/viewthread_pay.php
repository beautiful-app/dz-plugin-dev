<?PHP exit('Access Denied');?>
<!--{if $thread['freemessage']}-->
	<div id="postmessage_$pid" class="comiis_quote bg_h">$thread[freemessage]</div>
<!--{/if}-->
<!--{eval comiis_load('J65bJJEOOQKj1Gqq1L', 'thread,post');}-->