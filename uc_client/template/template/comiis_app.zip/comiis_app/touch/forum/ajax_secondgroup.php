<?PHP exit('Access Denied');?>
<!--{if !empty($groupselect['second'])}-->
<select id="fup" name="fup" class="ps">
	$groupselect[second]
</select>
<!--{/if}-->