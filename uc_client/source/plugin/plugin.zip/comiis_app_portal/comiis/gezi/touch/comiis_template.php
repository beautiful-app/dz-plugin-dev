<?PHP exit('Access Denied');?>
<style>
.comiis_mh_ge4 {width:100%;padding:5px 0;border-collapse:inherit;overflow:hidden;}
.comiis_mh_ge4 li {float:left;text-align:center;width:25%;box-sizing:border-box;}
.comiis_mh_ge4 li a {display:block;padding:10px;}
.comiis_mh_ge4 li img {width:46px;height:46px;margin-bottom:8px;border-radius:3px;}
.comiis_mh_ge4 li p {height:14px;line-height:14px;font-size:13px;}
</style>
{$comiis['summary']}