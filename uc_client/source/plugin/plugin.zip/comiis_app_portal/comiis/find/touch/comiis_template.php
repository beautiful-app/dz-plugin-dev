<?PHP exit('Access Denied');?>
<!--{eval hookscriptoutput('index');}-->
<!--{hook/global_comiis_app_find}-->