<?PHP exit('Access Denied');?>
<style>
.comiis_mh_gz03 {overflow:hidden;}
.comiis_mh_gz03 a {float:left;width:50%;height:76px;line-height:16px;padding:12px;box-sizing:border-box;overflow:hidden;}
.comiis_mh_gz03 a h2 {height:24px;line-height:24px;font-size:20px;font-weight:400;margin-top:2px;margin-bottom:6px;overflow:hidden;}
.comiis_mh_gz03 a img {float:right;width:52px;height:52px;border-radius:50%;}
</style>
{$comiis['summary']}