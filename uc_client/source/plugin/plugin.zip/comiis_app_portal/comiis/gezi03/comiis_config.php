<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_config, $comiis_portal;
$comiis_config = array(
	'name' => $comiis_portal['gezi03_a'],
	'dir' => 'gezi03',
	'copyright' => 'http://www.comiis.com',
	'version' => '2',
	'types' => '3',
	'install' => array('block'=>array('0'=>array( 'bid'=>0, 'blockclass'=>'html_html', 'blocktype'=>'1', 'name'=>'comiis', 'title'=>'', 'classname'=>'', 'summary'=>'<div class="comiis_mh_gz03 cl"><a href="#" class="b_r b_b"><img src="source/plugin/comiis_app_portal/image/001.png" class="vm"><h2 style="color:#FF9900">'.$comiis_portal['gezi03_b'].'</h2><span class="f_c">'.$comiis_portal['gezi03_c'].'</span></a><a href="#" class="b_b"><img src="source/plugin/comiis_app_portal/image/002.png" class="vm"><h2 style="color:#87D140">'.$comiis_portal['gezi03_d'].'</h2><span class="f_c">'.$comiis_portal['gezi03_e'].'</span></a><a href="#" class="b_r b_b"><img src="source/plugin/comiis_app_portal/image/003.png" class="vm"><h2 style="color:#20b4ff">'.$comiis_portal['gezi03_f'].'</h2><span class="f_c">'.$comiis_portal['gezi03_g'].'</span></a><a href="#" class="b_b"><img src="source/plugin/comiis_app_portal/image/004.png" class="vm"><h2 style="color:#FF5F45">'.$comiis_portal['gezi03_h'].'</h2><span class="f_c">'.$comiis_portal['gezi03_i'].'</span></a></div>', 'uid'=>'0', 'username'=>'comiis', 'styleid'=>'0', 'blockstyle'=>'', 'picwidth'=>'0', 'picheight'=>'0', 'target'=>'blank', 'dateformat'=>'Y-m-d', 'dateuformat'=>'0', 'script'=>'blank', 'param'=>array( 'content'=>'<div class="comiis_mh_gz03 cl"><a href="#" class="b_r b_b"><img src="source/plugin/comiis_app_portal/image/001.png" class="vm"><h2 style="color:#FF9900">'.$comiis_portal['gezi03_b'].'</h2><span class="f_c">'.$comiis_portal['gezi03_c'].'</span></a><a href="#" class="b_b"><img src="source/plugin/comiis_app_portal/image/002.png" class="vm"><h2 style="color:#87D140">'.$comiis_portal['gezi03_d'].'</h2><span class="f_c">'.$comiis_portal['gezi03_e'].'</span></a><a href="#" class="b_r b_b"><img src="source/plugin/comiis_app_portal/image/003.png" class="vm"><h2 style="color:#20b4ff">'.$comiis_portal['gezi03_f'].'</h2><span class="f_c">'.$comiis_portal['gezi03_g'].'</span></a><a href="#" class="b_b"><img src="source/plugin/comiis_app_portal/image/004.png" class="vm"><h2 style="color:#FF5F45">'.$comiis_portal['gezi03_h'].'</h2><span class="f_c">'.$comiis_portal['gezi03_i'].'</span></a></div>', 'items'=>10,), 'shownum'=>'10', 'cachetime'=>'0', 'cachetimerange'=>'0,0', 'punctualupdate'=>'0', 'hidedisplay'=>'0', 'dateline'=>'1485266568', 'notinherited'=>'0', 'isblank'=>'0',),),'style'=>array())
);