<?PHP exit('Access Denied');?>
<style>
.comiis_showimg11 {padding:7px;overflow:hidden;}
.comiis_showimg11 a {float:left;width:calc(33% - 10px);height:100px;margin:5px;overflow:hidden;}
.comiis_showimg11 a:nth-child(1), .comiis_showimg11 a:nth-child(3), .comiis_showimg11 a:nth-child(6) {width:calc(34% - 10px);}
.comiis_showimg11 a:nth-child(2) {width:calc(66% - 10px);}
.comiis_showimg11 a img {object-fit:cover;width:100%;height:100%;vertical-align:middle;border-radius:4px;}
</style>
{$comiis['summary']}