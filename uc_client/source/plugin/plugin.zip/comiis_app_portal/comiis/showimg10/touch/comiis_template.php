<?PHP exit('Access Denied');?>
<style>
.comiis_showimg10 {padding:7px;overflow:hidden;}
.comiis_showimg10 a {float:left;width:calc(33% - 10px);height:100px;margin:5px;overflow:hidden;}
.comiis_showimg10 a:nth-child(1) {float:right;width:calc(66% - 10px);height:210px;}
.comiis_showimg10 a:nth-child(2), .comiis_showimg10 a:nth-child(3), .comiis_showimg10 a:nth-child(4), .comiis_showimg10 a:nth-child(7) {width:calc(34% - 10px);}
.comiis_showimg10 a img {object-fit:cover;width:100%;height:100%;vertical-align:middle;border-radius:4px;}
</style>
{$comiis['summary']}