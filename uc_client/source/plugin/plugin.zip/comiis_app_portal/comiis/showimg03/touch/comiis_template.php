<?PHP exit('Access Denied');?>
<style>
.comiis_guanggao_tit {overflow:hidden;}
.comiis_guanggao_tit a {display:block;margin:7px 12px 12px;overflow:hidden;}
.comiis_guanggao_tit h2 {font-size:16px;line-height:28px;font-weight:400;}
.comiis_guanggao_tit h2 span {float:left;height:18px;line-height:18px;padding:0 4px;font-size:12px;margin-top:5px;margin-right:5px;overflow:hidden;border-radius:1.5px;}
.comiis_guanggao_tit img {margin-top:5px;width:100%;height:auto;vertical-align:middle;border-radius:4px;}
</style>
{$comiis['summary']}