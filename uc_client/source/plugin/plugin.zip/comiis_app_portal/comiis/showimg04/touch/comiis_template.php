<?PHP exit('Access Denied');?>
<style>
.comiis_showimg04 {padding:12px;overflow:hidden;}
.comiis_showimg04 a {width:calc(50% - 5px);height:100px;overflow:hidden;}
.comiis_showimg04 a:nth-child(1) {float:left;margin-right:5px;}
.comiis_showimg04 a:nth-child(2) {float:right;margin-left:5px;}
.comiis_showimg04 a img {object-fit:cover;width:100%;height:100%;vertical-align:middle;border-radius:4px;}
</style>
{$comiis['summary']}