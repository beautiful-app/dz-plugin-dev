<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_config, $comiis_portal;
$comiis_config = array(
	'name' => $comiis_portal['footer01_a'],
	'dir' => 'footer01',
	'copyright' => 'http://www.comiis.com',
	'version' => '2',
	'types' => '3',
	'install' => array('block'=>array('0'=>array( 'bid'=>0, 'blockclass'=>'html_html', 'blocktype'=>'1', 'name'=>'comiis', 'title'=>'', 'classname'=>'', 'summary'=>'<div class="comiis_mh_footnv"><a href="index.php">'.$comiis_portal['footer01_b'].'</a><span class="f_d">|</span><a href="forum.php?forumlist=1">'.$comiis_portal['footer01_c'].'</a><span class="f_d">|</span><a href="search.php?mod=forum">'.$comiis_portal['footer01_d'].'</a><span class="f_d">|</span><a href="plugin.php?id=comiis_app_activity">'.$comiis_portal['footer01_e'].'</a><span class="f_d">|</span><a href="plugin.php?id=comiis_app_find">'.$comiis_portal['footer01_f'].'</a></div><div class="comiis_mh_copy f_d">Copyright &copy 2019 Comiis.Com</div>', 'uid'=>'0', 'username'=>'comiis', 'styleid'=>'0', 'blockstyle'=>'', 'picwidth'=>'0', 'picheight'=>'0', 'target'=>'blank', 'dateformat'=>'Y-m-d', 'dateuformat'=>'0', 'script'=>'blank', 'param'=>array( 'content'=>'<div class="comiis_mh_footnv"><a href="index.php">'.$comiis_portal['footer01_b'].'</a><span class="f_d">|</span><a href="forum.php?forumlist=1">'.$comiis_portal['footer01_c'].'</a><span class="f_d">|</span><a href="search.php?mod=forum">'.$comiis_portal['footer01_d'].'</a><span class="f_d">|</span><a href="plugin.php?id=comiis_app_activity">'.$comiis_portal['footer01_e'].'</a><span class="f_d">|</span><a href="plugin.php?id=comiis_app_find">'.$comiis_portal['footer01_f'].'</a></div><div class="comiis_mh_copy f_d">Copyright &copy 2019 Comiis.Com</div>', 'items'=>10,), 'shownum'=>'10', 'cachetime'=>'0', 'cachetimerange'=>'0,0', 'punctualupdate'=>'0', 'hidedisplay'=>'0', 'dateline'=>'1474938092', 'notinherited'=>'0', 'isblank'=>'0',),),'style'=>array())
);