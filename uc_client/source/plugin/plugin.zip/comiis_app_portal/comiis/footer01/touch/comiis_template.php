<?PHP exit('Access Denied');?>
<style>
.comiis_mh_foot {padding:12px 0;text-align:center;}
.comiis_mh_footnv {height:28px;line-height:28px;font-size:14px;text-align:center;}
.comiis_mh_footnv a {display:inline-block;padding:0 10px;}
.comiis_mh_copy {height:26px;line-height:26px;text-align:center;}
</style>
<div class="comiis_mh_foot cl">
    {$comiis['summary']}
</div>