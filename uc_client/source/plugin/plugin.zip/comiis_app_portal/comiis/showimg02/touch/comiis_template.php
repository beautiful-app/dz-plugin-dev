<?PHP exit('Access Denied');?>
<style>
.bg_f.cl a img {vertical-align:middle;}
</style>
{$comiis['summary']}