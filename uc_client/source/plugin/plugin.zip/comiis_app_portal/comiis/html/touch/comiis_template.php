<?PHP exit('Access Denied');?>
{$comiis['summary']}