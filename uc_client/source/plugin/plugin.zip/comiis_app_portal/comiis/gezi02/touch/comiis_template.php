<?PHP exit('Access Denied');?>
<style>
.comiis_mh_gz02 {overflow:hidden;}
.comiis_mh_gz02 a {float:left;width:33.33%;line-height:20px;padding:10px 12px;font-size:13px;text-align:center;box-sizing:border-box;overflow:hidden;}
.comiis_mh_gz02 a h2 {height:24px;line-height:24px;font-size:18px;font-weight:400;margin-top:2px;overflow:hidden;}
</style>
{$comiis['summary']}