<?PHP exit('Access Denied');?>
<style>
.comiis_mh_ge5 {width:100%;padding:10px 6px;border-collapse:inherit;box-sizing:border-box;overflow:hidden;}
.comiis_mh_ge5 li {float:left;text-align:center;width:20%;box-sizing:border-box;}
.comiis_mh_ge5 li a {display:block;padding:5px;}
.comiis_mh_ge5 li img {width:46px;height:46px;margin-bottom:8px;border-radius:3px;}
.comiis_mh_ge5 li p {height:14px;line-height:14px;font-size:13px;}
</style>
{$comiis['summary']}