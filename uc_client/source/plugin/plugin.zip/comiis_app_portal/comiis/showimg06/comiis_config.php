<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_config, $comiis_portal;
$comiis_config = array(
	'name' => $comiis_portal['showimg06_a'],
	'dir' => 'showimg06',
	'copyright' => 'http://www.comiis.com',
	'version' => '2',
	'types' => '4',
	'install' => array('block'=>array('0'=>array( 'bid'=>0, 'blockclass'=>'html_html', 'blocktype'=>'1', 'name'=>'comiis', 'title'=>'', 'classname'=>'', 'summary'=>'<div class="comiis_showimg06 cl"><a href="#"><img src="source/plugin/comiis_app_portal/comiis/showimg06/img/001.jpg" class="vm"></a><a href="#"><img src="source/plugin/comiis_app_portal/comiis/showimg06/img/002.jpg" class="vm"></a><a href="#"><img src="source/plugin/comiis_app_portal/comiis/showimg06/img/003.jpg" class="vm"></a></div>', 'uid'=>'0', 'username'=>'comiis', 'styleid'=>'0', 'blockstyle'=>'', 'picwidth'=>'0', 'picheight'=>'0', 'target'=>'blank', 'dateformat'=>'Y-m-d', 'dateuformat'=>'0', 'script'=>'blank', 'param'=>array( 'content'=>'<div class="comiis_showimg06 cl"><a href="#"><img src="source/plugin/comiis_app_portal/comiis/showimg06/img/001.jpg" class="vm"></a><a href="#"><img src="source/plugin/comiis_app_portal/comiis/showimg06/img/002.jpg" class="vm"></a><a href="#"><img src="source/plugin/comiis_app_portal/comiis/showimg06/img/003.jpg" class="vm"></a></div>', 'items'=>10,), 'shownum'=>'10', 'cachetime'=>'3600', 'cachetimerange'=>'', 'punctualupdate'=>'0', 'hidedisplay'=>'0', 'dateline'=>'1475032468', 'notinherited'=>'0', 'isblank'=>'0',),),'style'=>array())
);