<?PHP exit('Access Denied');?>
<style>
.comiis_showimg06 {padding:7px;overflow:hidden;}
.comiis_showimg06 a {float:left;width:calc(33% - 10px);height:100px;margin:5px;overflow:hidden;}
.comiis_showimg06 a:nth-child(1) {width:calc(67% - 10px);height:210px;}
.comiis_showimg06 a:nth-child(4) {width:calc(34% - 10px);}
.comiis_showimg06 a:nth-child(5) {width:calc(33% - 10px);}
.comiis_showimg06 a img {object-fit:cover;width:100%;height:100%;vertical-align:middle;border-radius:4px;}
</style>
{$comiis['summary']}