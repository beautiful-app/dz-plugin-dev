<?PHP exit('Access Denied');?>
<style>
.comiis_mh_gz04 {padding:9px;overflow:hidden;}
.comiis_mh_gz04 a {float:left;width:calc(50% - 6px);height:70px;line-height:16px;padding:8px 10px;margin:3px;box-sizing:border-box;background:#53BCF5;overflow:hidden;border-radius:3px;}
.comiis_mh_gz04 a h2 {height:24px;line-height:24px;font-size:20px;font-weight:400;margin-top:1px;margin-bottom:9px;overflow:hidden;}
.comiis_mh_gz04 a span {font-size:11px;padding:2px 6px;border-radius:8px;}
.comiis_mh_gz04 a img {float:right;width:52px;height:52px;border-radius:4px;}
</style>
{$comiis['summary']}