<?PHP exit('Access Denied');?>
<style>
.comiis_mh_nav03 {box-sizing:border-box;padding:6px 0;overflow:hidden;}
.comiis_mh_nav03 {line-height:28px;font-size:16px;box-sizing:border-box;}
.comiis_mh_nav03 li a {display:block;text-align:center;text-overflow:ellipsis;}
</style>
<div class="comiis_mh_nav03 cl">  
   {$comiis['summary']}
</div>