<?PHP exit('Access Denied');?>
<style>
.comiis_mh_txt4 {margin:0 10px;position:relative;overflow:hidden;}
.comiis_mh_txt4 li {float:left;width:calc(50% - 10px);padding:0 5px;font-size:14px;}
.comiis_mh_txt4 li:nth-child(1), .comiis_mh_txt4 li:nth-child(2) {border-top:none !important}
.comiis_mh_txt4 li:nth-child(2n+0) {width:calc(50% - 11px);}
.comiis_mh_txt4 li a {display:block;height:24px;line-height:24px;margin:6px 0;}
.comiis_mh_txt4 li a img {float:left;width:22px;height:22px;border-radius:2px;margin-top:1px;margin-right:6px;}
</style>
{$comiis['summary']}