<?php
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_config, $comiis_portal;
$comiis_config = array(
	'name' => $comiis_portal['gezi04_a'],
	'dir' => 'gezi04',
	'copyright' => 'http://www.comiis.com',
	'version' => '2',
	'types' => '3',
	'install' => array('block'=>array('0'=>array( 'bid'=>0, 'blockclass'=>'html_html', 'blocktype'=>'1', 'name'=>'comiis', 'title'=>'', 'classname'=>'', 'summary'=>'<div class="comiis_mh_txt4 cl"><li class="b_t"><a href="#" class="b_r"><img src="source/plugin/comiis_app_portal/image/a01.png">#'.$comiis_portal['gezi04_b'].'#</a></li><li class="b_t"><a href="#"><img src="source/plugin/comiis_app_portal/image/a03.png">#'.$comiis_portal['gezi04_b'].'#</a></li><li class="b_t"><a href="#" class="b_r"><img src="source/plugin/comiis_app_portal/image/a11.png">#'.$comiis_portal['gezi04_b'].'#</a></li><li class="b_t"><a href="#"><img src="source/plugin/comiis_app_portal/image/a12.png">#'.$comiis_portal['gezi04_b'].'#</a></li></div>', 'uid'=>'0', 'username'=>'comiis', 'styleid'=>'0', 'blockstyle'=>'', 'picwidth'=>'0', 'picheight'=>'0', 'target'=>'blank', 'dateformat'=>'Y-m-d', 'dateuformat'=>'0', 'script'=>'blank', 'param'=>array( 'content'=>'<div class="comiis_mh_txt4 cl"><li class="b_t"><a href="#" class="b_r"><img src="source/plugin/comiis_app_portal/image/a01.png">#'.$comiis_portal['gezi04_b'].'#</a></li><li class="b_t"><a href="#"><img src="source/plugin/comiis_app_portal/image/a03.png">#'.$comiis_portal['gezi04_b'].'#</a></li><li class="b_t"><a href="#" class="b_r"><img src="source/plugin/comiis_app_portal/image/a11.png">#'.$comiis_portal['gezi04_b'].'#</a></li><li class="b_t"><a href="#"><img src="source/plugin/comiis_app_portal/image/a12.png">#'.$comiis_portal['gezi04_b'].'#</a></li></div>', 'items'=>10,), 'shownum'=>'10', 'cachetime'=>'0', 'cachetimerange'=>'0,0', 'punctualupdate'=>'0', 'hidedisplay'=>'0', 'dateline'=>'1485266568', 'notinherited'=>'0', 'isblank'=>'0',),),'style'=>array())
);