<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_config, $comiis_portal;
$comiis_config = array(
	'name' => $comiis_portal['footer02_a'],
	'dir' => 'footer02',
	'copyright' => 'http://www.comiis.com',
	'version' => '2',
	'type' => 'footer',
	'types' => '3',
	'install' => array('block'=>array('0'=>array( 'bid'=>0, 'blockclass'=>'html_html', 'blocktype'=>'1', 'name'=>'comiis', 'title'=>'', 'classname'=>'', 'summary'=>'<li class="flex f_0"><a href="#"><i class="comiis_font">&#xe662</i><span>'.$comiis_portal['footer02_b'].'</span></a></li><li class="flex f_c"><a href="#"><i class="comiis_font">&#xe665</i><span>'.$comiis_portal['footer02_b'].'</span></a></li><li class="flex comiis_fbigbtn"><a href="javascript:;" class="comiis_openfootbox"><em class="bg_f b_ok"></em><span class="bg_f"><i class="comiis_font foot_btn bg_0 f_f">&#xe610</i></span></a></li><li class="flex f_c"><a href="#"><i class="comiis_font">&#xe66c</i><span>'.$comiis_portal['footer02_b'].'</span></a></li><li class="flex f_c"><a href="#"><i class="comiis_font">&#xe62e</i><span>'.$comiis_portal['footer02_b'].'</span></a></li>', 'uid'=>'0', 'username'=>'comiis', 'styleid'=>'0', 'blockstyle'=>'', 'picwidth'=>'0', 'picheight'=>'0', 'target'=>'blank', 'dateformat'=>'Y-m-d', 'dateuformat'=>'0', 'script'=>'blank', 'param'=>array( 'content'=>'<li class="flex f_0"><a href="#"><i class="comiis_font">&#xe662</i><span>'.$comiis_portal['footer02_b'].'</span></a></li><li class="flex f_c"><a href="#"><i class="comiis_font">&#xe665</i><span>'.$comiis_portal['footer02_b'].'</span></a></li><li class="flex comiis_fbigbtn"><a href="javascript:;" class="comiis_openfootbox"><em class="bg_f b_ok"></em><span class="bg_f"><i class="comiis_font foot_btn bg_0 f_f">&#xe610</i></span></a></li><li class="flex f_c"><a href="#"><i class="comiis_font">&#xe66c</i><span>'.$comiis_portal['footer02_b'].'</span></a></li><li class="flex f_c"><a href="#"><i class="comiis_font">&#xe62e</i><span>'.$comiis_portal['footer02_b'].'</span></a></li>', 'items'=>10,), 'shownum'=>'10', 'cachetime'=>'0', 'cachetimerange'=>'0,0', 'punctualupdate'=>'0', 'hidedisplay'=>'0', 'dateline'=>'1474938092', 'notinherited'=>'0', 'isblank'=>'0',),),'style'=>array())
);