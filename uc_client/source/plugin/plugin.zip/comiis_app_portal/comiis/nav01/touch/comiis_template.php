<?PHP exit('Access Denied');?>
<style>
.comiis_mh_nav {line-height:40px;font-size:15px;box-sizing:border-box;}
.comiis_mh_nav li a {display:block;text-align:center;text-overflow:ellipsis;}
</style>
<div class="comiis_mh_nav cl">  
   {$comiis['summary']}
</div>