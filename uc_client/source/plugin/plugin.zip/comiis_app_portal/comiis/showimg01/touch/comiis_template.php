<?PHP exit('Access Denied');?>
<style>
.comiis_guanggao {padding:12px;overflow:hidden;}
.comiis_guanggao img {vertical-align:middle;border-radius:4px;}
</style>
<div class="comiis_guanggao cl">
{$comiis['summary']}
</div>