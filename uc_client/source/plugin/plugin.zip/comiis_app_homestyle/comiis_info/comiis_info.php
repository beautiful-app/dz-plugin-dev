<?php

 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$comiis_info = array(
	'sn' => '123',
	'siteurl' => 'http://123/',
	'clienturl' => 'http://123/',
	'siteid' => '123',
	'qqid' => '123',
	'revisionid' => '69351',
	'md5' => '123',
);