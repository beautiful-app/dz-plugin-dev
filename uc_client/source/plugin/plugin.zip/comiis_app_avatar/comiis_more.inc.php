<?PHP

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='http://www.huaidanwangluo.com';</script>";
?>