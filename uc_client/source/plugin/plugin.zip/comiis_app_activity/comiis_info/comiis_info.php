<?php
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$comiis_info = array(
	'sn' => '{ADDONVAR:SN}',
	'siteurl' => '{ADDONVAR:SiteUrl}',
	'clienturl' => '{ADDONVAR:ClientUrl}',
	'siteid' => '{ADDONVAR:SiteID}',
	'qqid' => '{ADDONVAR:QQID}',
	'revisionid' => '{ADDONVAR:RevisionID}',
	'md5' => '{ADDONVAR:MD5}',
);
