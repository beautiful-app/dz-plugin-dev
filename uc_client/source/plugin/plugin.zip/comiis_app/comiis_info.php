<?php
/**
 * 
 * www.52lcx.cn   
 * 
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_app_site;
$comiis_app_site = array(
	'auths' => '',
	'md5' => ''
);
