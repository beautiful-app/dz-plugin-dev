<?php

global $_G;
global $comiis_app_info;
global $comiis_md5file;
global $comiis_app_time;
global $re_sn;
$plugin_id = "comiis_app";
$_var_7 = 0;