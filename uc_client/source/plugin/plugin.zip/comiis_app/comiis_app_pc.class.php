<?php
/**
 * 
 * WWW.HUAIDANWANGLUO.COM   
 * 
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_comiis_app {
	function global_header() {
		return '<link rel="stylesheet" type="text/css" href="template/comiis_app/comiis/comiis_flxx/comiis_pcflxx.css" />';
	}
}
