<?php
if(!defined('IN_DISCUZ')){exit('Access Denied');}
$comiis_time = array('dateline'=>'1527494894', 'md5'=>'7ae5412fc07fe1b19a115aaa75ea67cf');