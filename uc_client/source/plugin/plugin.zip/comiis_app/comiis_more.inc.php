<?PHP

/**
 * 
 * ��������   bbs.huaidanwangluo.com   
 * 
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='http://52lcx.com';</script>";
