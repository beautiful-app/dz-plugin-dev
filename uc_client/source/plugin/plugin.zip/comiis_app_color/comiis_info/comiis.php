<?php

if (!defined("IN_DISCUZ")) {
	echo "Access Denied";
	return 0;
}