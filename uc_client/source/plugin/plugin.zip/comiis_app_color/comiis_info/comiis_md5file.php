<?php
if(!defined('IN_DISCUZ')){exit('Access Denied');}
global $comiis_poster_time;
$comiis_poster_time = array();