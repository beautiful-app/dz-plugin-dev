<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $comiis_poster_info;
$comiis_poster_info = array(
	'sn' => '',
	'siteurl' => 'http://127.0.0.1/',
	'clienturl' => 'http://127.0.0.1/',
	'siteid' => '',
	'qqid' => '',
	'revisionid' => '',
	'md5' => '',
);
?>