<style></style>
				<script>
				function comiis_app_portal_loop(h, speed, delay, sid) {
					var t = null;
					var o = document.getElementById(sid);
					o.innerHTML += o.innerHTML;
					o.scrollTop = 0;
					function start() {
						t = setInterval(scrolling, speed);
						o.scrollTop += 2;
					}
					function scrolling() {
						if(o.scrollTop % h != 0) {
							o.scrollTop += 2;
							if(o.scrollTop >= o.scrollHeight / 2) o.scrollTop = 0;
						} else {
							clearInterval(t);
							setTimeout(start, delay);
						}
					}
					setTimeout(start, delay);
				}
				function comiis_app_portal_swiper(a, b){
					if(typeof(Swiper) == 'undefined') {
						$.getScript("./source/plugin/comiis_app_portal/image/comiis.js").done(function(){
							new Swiper(a, b);
						});
					}else{
						new Swiper(a, b);
					}
				}
				</script><div id="comiis_app_block_130" class="bg_f cl"><style>
.comiis_mh_nav_jd {height:40px;width:100%;overflow:hidden;}
.comiis_mh_nav_jdbox {height:40px;position:relative;}
.comiis_mh_nav_jdsub {height:40px;text-align:center;white-space:nowrap;width:100%;}
.comiis_mh_nav_jdsub li {float:left;width:auto;overflow:hidden;position:relative;}
.comiis_mh_nav_jdsub em {position:absolute;left:50%;bottom:2px;margin-left:-9px;height:4px;width:18px;border-radius:10px;}
.comiis_mh_nav_jdsub a {display:inline-block;font-size:15px;height:40px;line-height:40px;padding:0 12px;}
</style>
<div style="height:40px;"><div class="comiis_scrollTop_box"><div class="comiis_mh_nav_jd bg_f b_b">
<div class="comiis_mh_nav_jdbox">
<div class="comiis_mh_nav_jdsub">
<ul class="comiis_flex">
<li class="flex f_b"><a href="forum.php?forumlist=1">版区</a></li>
<li class="flex f_b"><a href="plugin.php?id=comiis_app_portal&pid=10">新帖</a></li>
<li class="flex f_b"><a href="plugin.php?id=comiis_app_portal&pid=11">热图</a></li>
<li class="flex f_0"><em class="bg_0"></em><a href="javascript:;">精选</a></li></ul>
</div>
</div>
</div>
</div></div></div><div id="comiis_app_block_129" class="bg_f b_b cl"><style>
.comiis_mh_img14 {overflow:hidden;position:relative;}
.comiis_mh_img14 .swiper-slide h2 {position:absolute;left:0;bottom:0;color:#fff;width:100%;height:55px;padding:8px 0 12px;background:rgba(0,0,0,0.2);overflow:hidden;}
.comiis_mh_img14 .swiper-slide h2 span.kmtit {display:block;height:30px;line-height:30px;padding:0 12px;margin-bottom:5px;font-size:18px;font-weight:400;}
.comiis_mh_img14 .swiper-slide h2 span.kmuser {display:block;height:20px;line-height:20px;padding:0 12px;font-weight:400;}
.comiis_mh_img14 .swiper-slide h2 span.kmuser img {float:left;width:20px;height:20px;margin-right:6px;border-radius:50%;}
.comiis_mh_img14 .swiper-slide h2 span.kmuser em {padding:0 10px;}
.comiis_mh_img14_roll {position:absolute;right:10px;bottom:14px;height:16px;width:100%;text-align:right;z-index:9;overflow:hidden;}
.comiis_mh_img14_roll .swiper-pagination-bullet {display:inline-block;width:8px;height:8px;margin:0 2px;background-color:rgba(255, 255, 255, 1);border-radius:10px;}
.comiis_mh_img14_roll .swiper-pagination-bullet-active {background-color:#F90;}
</style>
<div class="comiis_mh_img14 comiis_mh_img14129">
<ul class="swiper-wrapper">
    <li class="swiper-slide">
            <a href="forum.php?mod=viewthread&tid=17514" title="有没有养“六角恐龙”的？">
<img src="data/attachment/block/0a/0aec27fd5b97c76bb3524177225c6c43.jpg" width="100%" class="vm comiis_mh_img14_whb129" alt="有没有养“六角恐龙”的？">
<h2><span class="kmtit">有没有养“六角恐龙”的？</span><span class="kmuser"><img src="http://www.ylqsz.cn/uc_server/avatar.php?uid=1&size=middle" class="vm">鱼乐圈<em class="comiis_tm">|</em>600人阅读&nbsp;&nbsp;&nbsp;2人回复</span></h2>
</a>
</li>
<li class="swiper-slide">
            <a href="forum.php?mod=viewthread&tid=127" title="《紫蓝花水泡》金鱼详细介绍">
<img src="data/attachment/block/e8/e84e2a2ad3c02ffcea40ccaa30e52e4c.jpg" width="100%" class="vm comiis_mh_img14_whb129" alt="《紫蓝花水泡》金鱼详细介绍">
<h2><span class="kmtit">《紫蓝花水泡》金鱼详细介绍</span><span class="kmuser"><img src="http://www.ylqsz.cn/uc_server/avatar.php?uid=1&size=middle" class="vm">鱼乐圈<em class="comiis_tm">|</em>266人阅读&nbsp;&nbsp;&nbsp;0人回复</span></h2>
</a>
</li>
<li class="swiper-slide">
            <a href="forum.php?mod=viewthread&tid=88" title="锦鲤品种之&lt;银松叶锦鲤&gt;">
<img src="data/attachment/forum/201803/28/154507p9khrj9cmmlr18p8.bmp" width="100%" class="vm comiis_mh_img14_whb129" alt="锦鲤品种之&lt;银松叶锦鲤&gt;">
<h2><span class="kmtit">锦鲤品种之&lt;银松叶锦鲤&gt;</span><span class="kmuser"><img src="http://www.ylqsz.cn/uc_server/avatar.php?uid=1&size=middle" class="vm">鱼乐圈<em class="comiis_tm">|</em>192人阅读&nbsp;&nbsp;&nbsp;0人回复</span></h2>
</a>
</li>
<li class="swiper-slide">
            <a href="forum.php?mod=viewthread&tid=70" title="锦鲤品种之&lt;赤别甲锦鲤&gt;">
<img src="data/attachment/block/2b/2b88cde71e80e7aaf895237b3d96b709.jpg" width="100%" class="vm comiis_mh_img14_whb129" alt="锦鲤品种之&lt;赤别甲锦鲤&gt;">
<h2><span class="kmtit">锦鲤品种之&lt;赤别甲锦鲤&gt;</span><span class="kmuser"><img src="http://www.ylqsz.cn/uc_server/avatar.php?uid=1&size=middle" class="vm">鱼乐圈<em class="comiis_tm">|</em>211人阅读&nbsp;&nbsp;&nbsp;0人回复</span></h2>
</a>
</li>
<li class="swiper-slide">
            <a href="forum.php?mod=viewthread&tid=92" title="锦鲤品种之&lt;金昭和光写锦鲤&gt;">
<img src="data/attachment/block/6d/6da6053c5334d4357fda23f6805b9d33.jpg" width="100%" class="vm comiis_mh_img14_whb129" alt="锦鲤品种之&lt;金昭和光写锦鲤&gt;">
<h2><span class="kmtit">锦鲤品种之&lt;金昭和光写锦鲤&gt;</span><span class="kmuser"><img src="http://www.ylqsz.cn/uc_server/avatar.php?uid=1&size=middle" class="vm">鱼乐圈<em class="comiis_tm">|</em>258人阅读&nbsp;&nbsp;&nbsp;0人回复</span></h2>
</a>
</li>
</ul>
<div class="comiis_mh_img14_roll comiis_mh_img14_roll129"></div>
</div>
<script>
  $('.comiis_mh_img14_whb129').css('height', ($('.comiis_mh_img14_whb129').width() * 0.56) + 'px');
comiis_app_portal_swiper('.comiis_mh_img14129', {
slidesPerView : 'auto',
        pagination: '.comiis_mh_img14_roll129',
loop: true,
autoplay: 5000,
        autoplayDisableOnInteraction: false,
onTouchMove: function(swiper){
Comiis_Touch_on = 0;
},
onTouchEnd: function(swiper){
Comiis_Touch_on = 1;
},
});
</script></div><div id="comiis_app_block_128" class="bg_f mt10 b_t b_b cl"><style>
.comiis_mh_txt4 {margin:0 10px;position:relative;overflow:hidden;}
.comiis_mh_txt4 li {float:left;width:calc(50% - 10px);padding:0 5px;font-size:14px;}
.comiis_mh_txt4 li:nth-child(1), .comiis_mh_txt4 li:nth-child(2) {border-top:none !important}
.comiis_mh_txt4 li:nth-child(2n+0) {width:calc(50% - 11px);}
.comiis_mh_txt4 li a {display:block;height:24px;line-height:24px;margin:6px 0;}
.comiis_mh_txt4 li a img {float:left;width:22px;height:22px;border-radius:2px;margin-top:1px;margin-right:6px;}
</style>
<div class="comiis_mh_txt4 cl">
<li class="b_t"><a href="#" class="b_r"><img src="source/plugin/comiis_app_portal/image/a01.png">#网友爆料#</a></li>
<li class="b_t"><a href="#"><img src="source/plugin/comiis_app_portal/image/a03.png">#头条早知道#</a></li>
<li class="b_t"><a href="#" class="b_r"><img src="source/plugin/comiis_app_portal/image/a11.png">#赚金币赢大礼#</a></li>
<li class="b_t"><a href="#"><img src="source/plugin/comiis_app_portal/image/a12.png">#社区小卖部#</a></li>
</div></div>