<style></style>
				<script>
				function comiis_app_portal_loop(h, speed, delay, sid) {
					var t = null;
					var o = document.getElementById(sid);
					o.innerHTML += o.innerHTML;
					o.scrollTop = 0;
					function start() {
						t = setInterval(scrolling, speed);
						o.scrollTop += 2;
					}
					function scrolling() {
						if(o.scrollTop % h != 0) {
							o.scrollTop += 2;
							if(o.scrollTop >= o.scrollHeight / 2) o.scrollTop = 0;
						} else {
							clearInterval(t);
							setTimeout(start, delay);
						}
					}
					setTimeout(start, delay);
				}
				function comiis_app_portal_swiper(a, b){
					if(typeof(Swiper) == 'undefined') {
						$.getScript("./source/plugin/comiis_app_portal/image/comiis.js").done(function(){
							new Swiper(a, b);
						});
					}else{
						new Swiper(a, b);
					}
				}
				</script><div id="comiis_app_block_127" class="bg_f cl"><style>
.comiis_mh_nav_jd {height:40px;width:100%;overflow:hidden;}
.comiis_mh_nav_jdbox {height:40px;position:relative;}
.comiis_mh_nav_jdsub {height:40px;text-align:center;white-space:nowrap;width:100%;}
.comiis_mh_nav_jdsub li {float:left;width:auto;overflow:hidden;position:relative;}
.comiis_mh_nav_jdsub em {position:absolute;left:50%;bottom:2px;margin-left:-9px;height:4px;width:18px;border-radius:10px;}
.comiis_mh_nav_jdsub a {display:inline-block;font-size:15px;height:40px;line-height:40px;padding:0 12px;}
</style>
<div style="height:40px;"><div class="comiis_scrollTop_box"><div class="comiis_mh_nav_jd bg_f b_b">
<div class="comiis_mh_nav_jdbox">
<div class="comiis_mh_nav_jdsub">
<ul class="comiis_flex">
<li class="flex f_b"><a href="forum.php?forumlist=1">版区</a></li>
<li class="flex f_b"><a href="plugin.php?id=comiis_app_portal&pid=10">新帖</a></li>
<li class="flex f_0"><em class="bg_0"></em><a href="javascript:;">热图</a></li>
<li class="flex f_b"><a href="plugin.php?id=comiis_app_portal&pid=12">精选</a></li></ul>
</div>
</div>
</div>
</div></div></div><div id="comiis_app_block_126" class="bg_f b_b cl"><style>
.comiis_mhimg10_box {background-size:cover;background-repeat:no-repeat;background-position:center center;transition:background .5s;}
.comiis_mhimg10 {width:100%;padding:15px 0;overflow:hidden;background:rgba(0,0,0,.7);position:relative;}
.comiis_mhimg10 .swiper-slide span {position:absolute;left:0;right:0;bottom:0;display:block;box-sizing:border-box;-webkit-box-sizing:border-box;background:-webkit-linear-gradient(top,rgba(0,0,0,0) 0,rgba(0,0,0,.8) 100%);color:#fff;padding:13px 10px 0;font-size:15px;height:50px;line-height:34px;font-weight:400;overflow:hidden;}
.comiis_mhimg10 li {width:80%;box-sizing:border-box;transition:transform .5s;transform:scale(.9);overflow:hidden;}
.comiis_mhimg10 li.swiper-slide-active {transform:scale(1);}
@supports (-webkit-backdrop-filter:none){.comiis_mhimg10126{background:rgba(0,0,0,.4);-webkit-backdrop-filter:brightness(1) blur(8px)}}
</style>
<div class="comiis_mhimg10_box comiis_mhimg10_box126">
<div class="comiis_mhimg10 comiis_mhimg10126">
<ul class="swiper-wrapper"><li class="swiper-slide">
                <a href="forum.php?mod=viewthread&tid=17514" title="有没有养“六角恐龙”的？">
                    <img src="data/attachment/block/0a/0aec27fd5b97c76bb3524177225c6c43.jpg" width="100%" class="vm comiis_mhimg10_whbs126" alt="有没有养“六角恐龙”的？">
                    <span>有没有养“六角恐龙”的？</span>
                </a>
</li>
<li class="swiper-slide">
                <a href="forum.php?mod=viewthread&tid=127" title="《紫蓝花水泡》金鱼详细介绍">
                    <img src="data/attachment/block/e8/e84e2a2ad3c02ffcea40ccaa30e52e4c.jpg" width="100%" class="vm comiis_mhimg10_whbs126" alt="《紫蓝花水泡》金鱼详细介绍">
                    <span>《紫蓝花水泡》金鱼详细介绍</span>
                </a>
</li>
<li class="swiper-slide">
                <a href="forum.php?mod=viewthread&tid=88" title="锦鲤品种之&lt;银松叶锦鲤&gt;">
                    <img src="data/attachment/forum/201803/28/154507p9khrj9cmmlr18p8.bmp" width="100%" class="vm comiis_mhimg10_whbs126" alt="锦鲤品种之&lt;银松叶锦鲤&gt;">
                    <span>锦鲤品种之&lt;银松叶锦鲤&gt;</span>
                </a>
</li>
<li class="swiper-slide">
                <a href="forum.php?mod=viewthread&tid=70" title="锦鲤品种之&lt;赤别甲锦鲤&gt;">
                    <img src="data/attachment/block/2b/2b88cde71e80e7aaf895237b3d96b709.jpg" width="100%" class="vm comiis_mhimg10_whbs126" alt="锦鲤品种之&lt;赤别甲锦鲤&gt;">
                    <span>锦鲤品种之&lt;赤别甲锦鲤&gt;</span>
                </a>
</li>
<li class="swiper-slide">
                <a href="forum.php?mod=viewthread&tid=92" title="锦鲤品种之&lt;金昭和光写锦鲤&gt;">
                    <img src="data/attachment/block/6d/6da6053c5334d4357fda23f6805b9d33.jpg" width="100%" class="vm comiis_mhimg10_whbs126" alt="锦鲤品种之&lt;金昭和光写锦鲤&gt;">
                    <span>锦鲤品种之&lt;金昭和光写锦鲤&gt;</span>
                </a>
</li>
</ul>
</div>
</div>
<script>
  $('.comiis_mhimg10_whbs126').css('height', ($('.comiis_mhimg10_whbs126').width() * 0.56) + 'px');
comiis_app_portal_swiper('.comiis_mhimg10126', {
slidesPerView : 'auto',
        paginationType: 'fraction',
loop: true,
autoplay: 5000,
        autoplayDisableOnInteraction: false,
centeredSlides: true,
onTouchMove: function(swiper){
Comiis_Touch_on = 0;
},
onTouchEnd: function(swiper){
Comiis_Touch_on = 1;
},
onInit: function(swiper) {
$(".comiis_mhimg10_box126").css("background-image", 'url(' + $('.comiis_mhimg10126 .swiper-slide').eq(swiper.activeIndex).find('img').attr("src") + ')');
},
onSlideChangeStart: function(swiper) {
$(".comiis_mhimg10_box126").css("background-image", 'url(' + $('.comiis_mhimg10126 .swiper-slide').eq(swiper.activeIndex).find('img').attr("src") + ')');
}
});
</script></div>